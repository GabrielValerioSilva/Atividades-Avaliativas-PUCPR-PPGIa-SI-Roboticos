import os
from glob import glob
from setuptools import find_packages, setup

package_name = 'robot_tf2'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='gabriel_valerio',
    maintainer_email='gabriel@pucpr.br',
    description='TF2 e mapeamento global em odom',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'tf2_lidar_mapper = robot_tf2.tf2_lidar_mapper:main',
            'reactive_navigation = robot_tf2.reactive_navigation:main',
        ],
    },
)