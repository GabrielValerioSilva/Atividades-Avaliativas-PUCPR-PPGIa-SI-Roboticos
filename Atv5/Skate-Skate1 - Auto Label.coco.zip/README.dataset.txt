# Skate > skate-akovc
https://universe.roboflow.com/gabriels-workspace-qaagl/skate-akovc

Provided by a Roboflow user
License: CC BY 4.0

